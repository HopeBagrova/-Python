
a = 15
b = 20
c = "Привет"
print(c)
print("Переменные a и b - ", a, ",", b)


age = int (input("Введите ваш возраст:"))
name = input("Введите ваше имя:")
print(name, ", Вам", age, "!")
