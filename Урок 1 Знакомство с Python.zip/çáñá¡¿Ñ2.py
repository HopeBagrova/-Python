time = int (input("Введите время в секундах:"))
Hours = time // 3600
Minutes = (time -  Hours * 3600) // 60
Seconds = time - (Hours * 3600 + Minutes * 60)
print(f"Время в формате чч:мм:сс - {Hours} : {Minutes} : {Seconds}")