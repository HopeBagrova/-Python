

N = int(input("Введите число:"))
temp = str(N)
t1 = temp + temp
t2 = temp + temp + temp
comp = N + int(t1) + int(t2)
print("Cумма чисел n+nn+nnn:", comp)

